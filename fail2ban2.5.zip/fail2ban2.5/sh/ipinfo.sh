#!/bin/bash

DB="/var/lib/fail2ban/fail2ban.sqlite3"

# 1. 检查数据库文件权限
if [ ! -r "$DB" ]; then
    echo -e "\e[31m错误：无法读取数据库 $DB，请确认文件存在或使用 sudo 运行。\e[0m"
    exit 1
fi

# 2. 获取输入 IP
if [ -z "$1" ]; then
    read -p "请输入要检查的 IP: " IP
else
    IP="$1"
fi

# 3. 校验 IP 格式
if ! python3 -c "import ipaddress; ipaddress.ip_address('$IP')" >/dev/null 2>&1; then
    echo -e "\e[31m错误：'$IP' 不是一个有效的 IP 地址。\e[0m"
    exit 1
fi

# 4. 执行 SQLite 查询与美化输出
python3 - "$DB" "$IP" <<'PY'
import sys
import sqlite3
import unicodedata
from datetime import datetime, timezone

db_path = sys.argv[1]
target_ip = sys.argv[2]
now = int(datetime.now(timezone.utc).timestamp())

headers = ["IP", "策略", "封禁时间", "封禁秒数", "解封时间", "状态"]
rows = []

try:
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # 使用参数化查询防止 SQL 注入
    cursor.execute("""
        SELECT ip, jail, timeofban, bantime 
        FROM bans 
        WHERE ip = ? 
        ORDER BY timeofban DESC;
    """, (target_ip,))
    
    records = cursor.fetchall()
    conn.close()
except Exception as e:
    print(f"\033[31m数据库查询失败: {e}\033[0m")
    sys.exit(1)

if not records:
    print(f"未找到与 IP [{target_ip}] 相关的封禁记录。")
    sys.exit(0)

for ip, jail, ban_ts, bantime in records:
    ban_ts = int(ban_ts)
    bantime = int(bantime)
    unban_ts = ban_ts + bantime

    ban_time = datetime.fromtimestamp(ban_ts).strftime("%Y-%m-%d %H:%M:%S")

    if bantime < 0:
        unban_time = "永久"
        status = "\033[31m封禁中\033[0m" # 红色加亮
    else:
        unban_time = datetime.fromtimestamp(unban_ts).strftime("%Y-%m-%d %H:%M:%S")
        if unban_ts > now:
            status = "\033[31m封禁中\033[0m"
        else:
            status = "\033[32m已解封\033[0m" # 绿色加亮

    rows.append([ip, jail, ban_time, str(bantime), unban_time, status])

# 计算终端显示宽度 (解决全角/中文字符对齐问题)
def display_width(text):
    # 移除 ANSI 颜色代码后计算实际宽度
    clean_text = text.replace("\033[31m", "").replace("\033[32m", "").replace("\033[0m", "")
    width = 0
    for char in str(clean_text):
        if unicodedata.east_asian_width(char) in ("W", "F"):
            width += 2
        else:
            width += 1
    return width

def pad(text, width):
    text_str = str(text)
    # 补齐空格需要依据没有颜色代码时的实际字符物理宽度
    actual_w = display_width(text_str)
    return text_str + " " * (width - actual_w)

# 计算每一列的最大显示宽度
widths = []
for i, header in enumerate(headers):
    max_w = display_width(header)
    for row in rows:
        max_w = max(max_w, display_width(row[i]))
    widths.append(max_w)

# 输出表格
print("  ".join(pad(headers[i], widths[i]) for i in range(len(headers))))
print("  ".join("-" * widths[i] for i in range(len(headers))))

for row in rows:
    print("  ".join(pad(row[i], widths[i]) for i in range(len(headers))))
PY